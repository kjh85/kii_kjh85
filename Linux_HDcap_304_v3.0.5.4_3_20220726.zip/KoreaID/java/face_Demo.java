import java.io.*;
import java.util.*;
import java.nio.ByteBuffer;
import bio.face.Faceprint;



//////
class face_Demo {
	public static void main(String[] args) throws IOException{

		//String dbfilename = "1.bmp";
		String dbfilename = "face.jpg";
		String confPath = "/home/devibs1/KoreaID/";
		String cmmLibPath = "/home/devibs1/KoreaID/libup64h/";
		String unicode = "1234";  // number only for debug analysis or log analysis
		
		int KII_IMAGE_FORMAT_JPG = 1;		
		int KII_IMAGE_FORMAT_BMP = 2;		
		
		byte[] DBFeature = new byte[3500];  // db feature

		int len, dlen;
		

		// read input image
		FileInputStream fin = new FileInputStream(dbfilename);
		int count = fin.available();
		byte[] dbimage = new byte[count];

		dlen = fin.read(dbimage);
		String str = "dbimage Size" + dlen ;
		System.out.println(str);

		
		
		System.out.println(System.getProperty("java.library.path"));

		Faceprint fp;
		fp = new Faceprint();
		fp.jniFAStart(cmmLibPath);  // call this once from start of the program
		
		if (DBFeature != null )
		{

                        /////////////////   repeated call for each image Start    >>>>>  ///////////////////////////////

			  // extract feature
			  int rt2 = fp.jniFAExtractDB(confPath, unicode, dbimage, dlen, KII_IMAGE_FORMAT_JPG, DBFeature);     // bmp
			  str = "ExtractDB return=" + rt2 ;

			  System.out.println(str);
			
			  // save feature
			  FileOutputStream out1 = new FileOutputStream("1_NonFace_feature.f");
  			out1.write(DBFeature);
  			out1.close();  			
  			
  			
  			
  		}
  		
  		
  	

		fp.jniFAEnd();   // call this once at the end of the program
	}
}

